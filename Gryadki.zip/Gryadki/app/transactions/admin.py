from django.contrib import admin
from .models import  Site, Order

admin.site.register(Site)
admin.site.register(Order)