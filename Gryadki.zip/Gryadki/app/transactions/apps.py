import time
import json
import pytz
from woocommerce import API
from datetime import datetime
from multiprocessing import Process

from django.apps import AppConfig


def get_order_json(order):
    return {
        "status": order["status"],
        "date_created": order["date_created"],
        "name": order["meta_data"][0]["value"],
        "phone": order["billing"]["phone"] + order["shipping"]["phone"],
        "woocommerce_id": order["id"],
        "email": order["billing"]["email"],
        "address": order["billing"]["city"] + order["shipping"]["city"],
        "comment": order["customer_note"],
        "products": [
            {
                "product_name": product_item["name"],
                "quantity": product_item["quantity"],
                "meta_data": [
                {
                    "key_meta_data": meta_item["display_key"],
                    "val_meta_data": meta_item["display_value"]
                } for meta_item in product_item["meta_data"] 
                ]
            } for product_item in order["line_items"] 
        ],
        "total": order["total"]
    }


class SitesListening(Process):
    def __init__(self):
        super().__init__()
        self.daemon = True

    def run(self):
        from .models import Site, Order

        while True:

            sites = Site.objects.all()
            time.sleep(10)
            for site in sites:    
                wcapi = API(
                    url=site.domain,
                    consumer_key=site.consumer_key,
                    consumer_secret=site.consumer_secret,
                    timeout=50
                )
                response = wcapi.get('orders')
                for json_order in response.json():
                    moscow_tz = pytz.timezone('Europe/Moscow')
                    order_date_created = datetime.strptime(json_order["date_created"], '%Y-%m-%dT%H:%M:%S').astimezone(moscow_tz)
                    if site.last_update < order_date_created:
                        order = Order(site=site, items=get_order_json(json_order))
                        order.save()
                utc_now = datetime.utcnow()
                moscow_now = utc_now.replace(tzinfo=pytz.UTC).astimezone(moscow_tz)
                site.last_update = moscow_now
                site.save()
                time.sleep(10)


class TransactionsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'transactions'
    def ready(self):
        monitor = SitesListening()
        monitor.start()
