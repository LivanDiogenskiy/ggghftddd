from django.urls import path
from . import views

urlpatterns = [
    path('', views.OrderListView.as_view(), name='orders'),
    path('new', views.OrderCreateView.as_view(), name='new-order'),
    path('order/<pk>/edit', views.OrderUpdateView.as_view(), name='edit-order'),
    path('order/<pk>/delete', views.OrderDeleteView.as_view(), name='delete-order'),
]
