from django.db import models
from django_jsonform.models.fields import JSONField

class Site(models.Model):
    domain = models.CharField(max_length=150, unique=True)
    last_update = models.DateTimeField()
    consumer_key = models.CharField(max_length=150)
    consumer_secret = models.CharField(max_length=150)
    def __str__(self):
            return str(self.domain)

class Order(models.Model):
    ITEMS_SCHEMA = {
        "type": "object",
        "keys": {
            "status": {
                "type": "string",
                "title": "Статус",
                "choices": [
                    {
                    "title": "В ожидании платежа",
                    "value": "pending"
                    },
                    {
                    "title": "Неуспешно",
                    "value": "failed"
                    },
                    {
                    "title": "В обработке",
                    "value": "processing"
                    },
                    {
                    "title": "Выполнено",
                    "value": "completed"
                    },
                    {
                    "title": "В ожидании",
                    "value": "on-hold"
                    },
                    {
                    "title": "Отменено",
                    "value": "cancelled"
                    },
                    {
                    "title": "Возмещено",
                    "value": "refunded"
                    }
                ]
            },
            "date_created": {
                "type": "string",
                "title": "Дата создания заказа",
                "format": "date-time",
            },
            "name": {
                "type": "string",
                "title": "ФИО"
            },
            "phone": {
                "type": "string",
                "title": "Номер телефона"
            },
                "woocommerce_id": {
                "type": "integer",
                "title": "Woocommerce ID",
                "placeholder": "Необязательный параметр"
            },
            "email": {
                "type": "string",
                "title": "Email",
                "placeholder": "Необязательный параметр"
            },
            "address": {
                "type": "string",
                "title": "Адрес",
                "placeholder": "Необязательный параметр"
            },
            "comment": {
                "type": "string",
                "title": "Примечание к заказу",
                "widget": "textarea",
                "placeholder": "Необязательный параметр"
            },
            "products": {
                "type": "array",
                "title": "Список покупок",
                "items": {
                    "type": "object",
                    "keys": {
                        "product_name": {
                            "type": "string",
                            "title": "Название товара"
                        },
                        "quantity": {
                            "type": "integer",
                            "title": "Количество"
                        },
                        "meta_data": {
                            "type": "array",
                            "title": "Мета данные",
                            "items": {
                                "type": "object",
                                "keys": {
                                    "key_meta_data": {
                                        "type": "string",
                                        "title": "Название свойства"
                                    },
                                    "val_meta_data": {
                                        "type": "string",
                                        "title": "Значение свойства"
                                    },
                                },
                            },
                            "minItems": 0,
                            "maxItems": 100
                        },
                    },
                },
                "minItems": 1,
                "maxItems": 100
            },
            "total": {
                "type": "string",
                "title": "Итоговая стоимость"
            },
        }
    }

    site = models.ForeignKey(Site, on_delete=models.CASCADE)
    items = JSONField(schema=ITEMS_SCHEMA)

    def __str__(self):
	    return str(self.items["name"])