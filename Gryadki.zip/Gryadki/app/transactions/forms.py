from django import forms
from .models import Order
from django_jsonform.forms.fields import JSONFormField


class OrderForm(forms.ModelForm): 
    class Meta:
        model = Order
        fields = ["site", "items"]
    #first_name = JSONSchemaField(schema = first_name_schema, options = options)
    #items = JSONFormField(schema = Order.ITEMS_SCHEMA)
