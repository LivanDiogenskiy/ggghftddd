from django.shortcuts import render
from django.views.generic import View, TemplateView


class HomeView(View):
    template_name = "home.html"
    def get(self, request):        
       
        return render(request, self.template_name)

class AboutView(TemplateView):
    template_name = "about.html"